package com.mani.session4ass3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by sakshi.banger on 31-08-2016.
 */

public class GridViewAdapter extends BaseAdapter {
    Context mcontext;
    int image[]={R.drawable.honeycomb,R.drawable.gingerbread,R.drawable.icecream,R.drawable.jellybean,R.drawable.kitkat,R.drawable.lollipop};
    public GridViewAdapter(Context context) {
        mcontext=context;
    }

    @Override
    public int getCount() {
      return  image.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(mcontext).inflate(R.layout.grid,null);
        ImageView ivimage=(ImageView) convertView.findViewById(R.id.ivimage);
        ivimage.setImageResource(image[position]);
        return convertView;
    }
}
