package com.mani.session4ass3;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

public class MainActivity extends Activity {
    GridView gvusers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gvusers=(GridView)findViewById(R.id.gvusers);
        GridViewAdapter gridviewadapter=new GridViewAdapter(this);
        gvusers.setAdapter(gridviewadapter);
    }
}
